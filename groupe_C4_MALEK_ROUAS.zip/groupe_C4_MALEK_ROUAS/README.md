
# Projet UE Développement Web - "LF MUSIC"

Dans le cadre de notre projet de deuxième année licence, nous devons créer un site internet sur la musique, en récupérant une API
Le but du projet est d’apprendre à gérer un projet professionnel de la reformulation du cahier des charges jusqu’à sa réalisation complète en respectant les exigences du prof.
Vous verrez également dans ce projet une application directe des compétences acquises au cours de notre semestre notamment en ce qui concerne les langages PHP, HTML et CSS.


![Logo](https://www.francaisauthentique.com/wp-content/uploads/2018/09/Miniature-plus-vite-que-la-musique.png)


## Auteurs

- [@ROUAS Lila](https://github.com/elrouas)
- [@MALEK Feriel](https://github.com/malekferiel)



## Les URL du site sur Internet

 - [URL MALEK Feriel](http://malek.alwaysdata.net/)
 - [URL ROUAS Lila](http://rouasl.alwaysdata.net/)

## Encadrant
Marc LEMAIRE
## L'année universitaire
2021-2022

