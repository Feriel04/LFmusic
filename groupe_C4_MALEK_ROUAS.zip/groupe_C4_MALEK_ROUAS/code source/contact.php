<!DOCTYPE html>
<html lang="fr">
<head>
<title> Contact </title>
        <meta charset="utf-8"/>
        <link href="styles.css" rel= "stylesheet"  />
        <link rel="shortcut icon" href="./images/logooo.PNG"/>
    
        </head>
 <?php
        $titre = "Projet";
        require_once"./include/header.inc.php";
    
    ?>
    <?php 
    require"./include/functions.inc.php";
   ?>
      <main id="centre"  class="<?= $theme_class ?>">
  
    <article> <h2> vous voulez
en savoir plus ? </h2>
    <p>Bonjour,</p> 
 <p>
Ce site web est un espace qui vous permet d'écouter tous genre de musiques que vous voulez .
 </p>
 
<h2> Dévloppeurs </h2> 
<p>ROUAS Lila | MALEK Feriel</p>
<h2>Mails</h2>
<p>Lilarouas@gmail.com | Fyfyferiel44@gmail.com </p>

</article> 
 
 <?php
        require "./include/footer.inc.php";

    ?>
 </main>
 </html>
 